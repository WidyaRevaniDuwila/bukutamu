<?php include "header.php"; ?>

<?php 
//Uji Jika tombol simpan diklik
if (isset ($_POST['bsimpan'])) {
    $tgl = date('Y-m-d');
    // Data dari form tidak disanitasi
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $tujuan = $_POST['tujuan'];
    $nope = $_POST['nope'];

    $simpan = mysqli_query($koneksi, "INSERT INTO ttamu VALUES ('', '$tgl', '$nama', '$alamat', '$tujuan', '$nope')");

    if($simpan) {
        // Reflected XSS vulnerability pada alert
        echo "<script> alert('Data untuk " . $_POST['nama'] . " berhasil disimpan!'); document.location = '?' </script>";
    } else {
        echo "<script> alert('Simpan data GAGAL !!!'); document.location = '?' </script>";
    }
}

// Fungsi pencarian yang rentan terhadap Reflected XSS
$search_results = [];
if(isset($_GET['search'])) {
    $search = $_GET['search']; // Tidak ada sanitasi untuk search term
    $query = "SELECT * FROM ttamu WHERE nama LIKE '%$search%' OR alamat LIKE '%$search%' OR tujuan LIKE '%$search%'";
    $search_results = mysqli_query($koneksi, $query);
}
?>

    <!-- Head -->
    <div class="head text-center">
        <h2 class="text-white">Sistem Informasi Buku Tamu</h2>
    </div>
    <!-- end -->

    <!-- Form pencarian yang rentan terhadap Reflected XSS dan DOM-based XSS -->
    <div class="row mb-3">
        <div class="col-lg-12">
            <form method="GET" action="" class="mb-3">
                <div class="input-group">
                    <input type="text" id="searchInput" name="search" class="form-control" 
                           placeholder="Cari pengunjung..."
                           value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </div>
            </form>
            <!-- Kontainer untuk hasil pencarian real-time (DOM-based XSS) -->
            <div id="searchResults"></div>
        </div>
    </div>

    <!-- Menampilkan hasil pencarian - Reflected XSS -->
    <?php if(isset($_GET['search'])): ?>
        <div class="card mb-3">
            <div class="card-body">
                <!-- Reflected XSS vulnerability -->
                <h5 class="card-title">Hasil pencarian untuk: <?= $_GET['search'] ?></h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Tujuan</th>
                                <th>No. HP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if($search_results) {
                                $no = 1;
                                while($row = mysqli_fetch_array($search_results)) {
                                    // Reflected XSS - data ditampilkan tanpa sanitasi
                                    echo "<tr>
                                        <td>$no</td>
                                        <td>$row[tanggal]</td>
                                        <td>$row[nama]</td>
                                        <td>$row[alamat]</td>
                                        <td>$row[tujuan]</td>
                                        <td>$row[nope]</td>
                                    </tr>";
                                    $no++;
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- awal -->
    <div class="row mt-2">
        <!-- col lg-7 -->
        <div class="col-lg-7 mb-3">
            <div class="card shadow bg-gradient-light">
                <!-- card body -->
                <div class="card-body">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Identitas Pengunjung</h1>
                    </div>
                    <form class="user" method="POST" action="">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="nama" placeholder="Nama Pengunjung" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="alamat" placeholder="Alamat Pengunjung" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="tujuan" placeholder="Tujuan Pengunjung" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="nope" placeholder="No Hp Pengunjung" required>
                        </div>
                        <button type="submit" name="bsimpan" class="btn btn-primary btn-user btn-block">Simpan Data</button>
                    </form>
                    <hr>
                    <div class="text-center">
                        <a class="small" href="#">by. Widya Revani Duwila | 2021 - <?= date('Y') ?></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- end col lg-7 -->

        <!-- col lg-5 -->
        <div class="col-lg-5 mb-3">
            <!-- card -->
            <div class="card shadow">
                <!-- card body -->
                <div class="card-body">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Statistik Pengunjung</h1>
                    </div>
                    <?php
                    //deklarasi tanggal
                    $tgl_sekarang = date('Y-m-d');
                    $kemarin = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                    $seminggu = date('Y-m-d h:i:s', strtotime('-1 week +1 day', strtotime($tgl_sekarang))); 
                    $sekarang = date('Y-m-d h:i:s');

                    //Query statistik
                    $tgl_sekarang = mysqli_fetch_array(mysqli_query(
                        $koneksi, 
                        "SELECT count(*) FROM ttamu where tanggal like '%$tgl_sekarang%'"
                    ));
                    $kemarin = mysqli_fetch_array(mysqli_query(
                        $koneksi, 
                        "SELECT count(*) FROM ttamu where tanggal like '%$kemarin%'"
                    ));
                    $seminggu = mysqli_fetch_array(mysqli_query(
                        $koneksi, 
                        "SELECT count(*) FROM ttamu where tanggal BETWEEN '$seminggu' and '$sekarang'"
                    ));
                    $bulan_ini = date('m');
                    $sebulan = mysqli_fetch_array(mysqli_query(
                        $koneksi, 
                        "SELECT count(*) FROM ttamu where month(tanggal) = '$bulan_ini'"
                    ));
                    $keseluruhan = mysqli_fetch_array(mysqli_query(
                        $koneksi, 
                        "SELECT count(*) FROM ttamu"
                    ));
                    ?>
                    <table class="table table-bordered">
                        <tr>
                            <td>Hari Ini</td>
                            <td>: <?= $tgl_sekarang[0] ?></td>
                        </tr>
                        <tr>
                            <td>Kemarin</td>
                            <td>: <?= $kemarin[0] ?></td>
                        </tr>
                        <tr>
                            <td>Minggu ini</td>
                            <td>: <?= $seminggu[0] ?></td>
                        </tr>
                        <tr>
                            <td>Bulan Ini</td>
                            <td>: <?= $sebulan[0] ?></td>
                        </tr>
                        <tr>
                            <td>Keseluruhan</td>
                            <td>: <?= $keseluruhan[0] ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <!-- end col lg-5 -->
    </div>
    <!-- end row -->

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pengunjung Hari Ini [<?= date('Y-m-d') ?>]</h6>
        </div>
        <div class="card-body">
            <a href="rekapitulasi.php" class="btn btn-success mb-3"><i class="fa fa-table"></i> Rekapitulasi Pengunjung</a>
            <a href="logout.php" class="btn btn-danger mb-3"><i class="fa fa-sign-out-alt"></i> Logout</a>

            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Tanggal</th>
                            <th>Nama Pengunjung</th>
                            <th>Alamat</th>
                            <th>Tujuan</th>
                            <th>NO. Hp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $tgl = date('Y-m-d');
                        $tampil = mysqli_query($koneksi, "SELECT * FROM ttamu where tanggal like '%$tgl%' order by id desc");
                        $no = 1;
                        while ($data = mysqli_fetch_array($tampil)){
                            // Reflected XSS vulnerability - menampilkan data tanpa sanitasi
                            echo "<tr>
                                <td>$no</td>
                                <td>$data[tanggal]</td>
                                <td>$data[nama]</td>
                                <td>$data[alamat]</td>
                                <td>$data[tujuan]</td>
                                <td>$data[nope]</td>
                            </tr>";
                            $no++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<!-- Script untuk DOM-based XSS -->
<script>
// Pencarian real-time yang rentan terhadap DOM-based XSS
document.getElementById('searchInput').addEventListener('input', function() {
    var searchTerm = this.value;
    var resultsDiv = document.getElementById('searchResults');
    
    // Rentan terhadap DOM-based XSS - menggunakan innerHTML tanpa sanitasi
    resultsDiv.innerHTML = `
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Pencarian real-time</h5>
                <p>Mencari untuk: ${searchTerm}</p>
            </div>
        </div>
    `;

    // Jika ada input, lakukan pencarian AJAX
    if(searchTerm.length > 0) {
        fetch('search_ajax.php?term=' + searchTerm)
            .then(response => response.text())
            .then(data => {
                // DOM-based XSS - hasil ditampilkan tanpa sanitasi
                resultsDiv.innerHTML += data;
            });
    }
});

// Fungsi tambahan untuk DOM-based XSS dari parameter URL
function showMessage() {
    const urlParams = new URLSearchParams(window.location.search);
    if(urlParams.has('msg')) {
        const message = urlParams.get('msg');
        const div = document.createElement('div');
        // DOM-based XSS - pesan ditampilkan tanpa sanitasi
        div.innerHTML = `<div class="alert alert-info">${message}</div>`;
        document.body.insertBefore(div, document.body.firstChild);
    }
}

// Jalankan saat halaman dimuat
showMessage();
</script>

<?php include "footer.php"; ?>